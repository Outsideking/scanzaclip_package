# ScanzaClip Admin Skeleton
See docs folder for details.